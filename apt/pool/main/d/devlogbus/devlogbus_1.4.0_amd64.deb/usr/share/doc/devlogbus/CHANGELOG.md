# Changelog

## Unreleased

## v1.4.0 - 2026-10-03

This release adds saved investigation workspaces to the embedded browser viewer.

### Highlights

- Added named investigation workspaces to the browser viewer, with save, load,
  update, and delete controls for layouts, source visibility/blocking, filters,
  search, and pane preferences stored in the current browser.
- Updated the Go toolchain and `golang.org/x/text` to address security advisories
  reported by the local quality gate.
- Fixed a stale Homebrew tap path in the package-manager docs.
- Set the release workflow to use the Node 24 JavaScript action runtime.

## v1.3.2 - 2026-06-05

This release adds optional login protection for the embedded browser UI.

### Highlights

- Added UI-managed DevLogBus users with username, display name, and password
  setup from the Settings dialog.
- Added a login-mode toggle that keeps DevLogBus open by default and allows
  login enforcement to be turned on or off after users exist.
- Protected the browser UI's log/about/record HTTP APIs with a session cookie
  when login mode is enabled.
- Kept the default install and daemon behavior open for local developer
  workflows with no configured users.

## v1.3.1 - 2026-05-31

This release aligns SDK package metadata and adds native package-manager
distribution prep.

### Highlights

- Bumped SDK package metadata to `1.3.1` for npm, PyPI, crates.io, NuGet, and
  Maven Central publishing.
- Added Maven Central-ready JVM package metadata.
- Added Linux native package prep for Debian/Ubuntu, RPM/DNF, and Alpine
  package assets.
- Added Homebrew and Scoop publishing prep for binary installs.

## v1.3.0 - 2026-05-31

This release completes the first public multi-language SDK pass.

### Highlights

- Added C, .NET/C#, Rust, Java/Kotlin, Node/TypeScript, and Python SDK source
  packages for publishing records through the DevLogBus HTTP API.
- Added SDK-side record filter and redaction hooks for Go, C, .NET/C#, Rust,
  Java/Kotlin, Node/TypeScript, and Python publishers.
- Added SDK docs, examples, and local test coverage for the new SDK packages.

## v1.2.0 - 2026-05-31

This release prepares DevLogBus for broader public use.

### Highlights

- Added GitHub Actions release artifacts for macOS, Linux, Windows, checksums,
  and the Browser Tap Chrome Web Store package.
- Verified Linux and Windows release packages with platform smoke coverage.
- Added public package-manager prep, including Homebrew formula generation.
- Fixed release packaging scripts so relative output directories work reliably
  in local runs and GitHub Actions.
- Added Browser Tap controls for local host allow/deny filters, redaction, and
  Chrome Web Store-safe localhost host permissions.
- Added the publish-ready documentation set covering the daemon, browser UI,
  TUI, CLI, HTTP API, wire protocol, Browser Tap, journal bridge, Go SDK,
  security/privacy, configuration, compatibility, examples, and release notes.
- Added public examples for Go `slog`, Node/TypeScript, Python, and browser
  workflows.
- Added GitHub issue templates, contribution notes, a security policy, and
  browser UI screenshot/GIF assets.
- Added the MIT License and release packaging support for carrying the license
  into archives and generated package-manager formulas.

## v1.1.0 - 2026-05-30

### Highlights

- Added public runtime controls for enabling, disabling, and retargeting
  DevLogBus logging from Go applications.
- Kept runtime controls independent from private application settings,
  service-template, CLI-template, RPC, and business-specific packages.
- Added package-level tests for runtime status, endpoint changes, and
  non-blocking handler behavior.

## v1.0.0 - 2026-05-28

Version 1 marks DevLogBus as a usable local-first development log bus for
real-time app debugging.

### Highlights

- Local broker daemon with a stable default Unix socket at
  `/tmp/devlogbus/devlogbus.sock`, optional TCP listener, HTTP API, embedded
  React viewer, replay, SSE streaming, and expunge support.
- CLI tools for emitting records, tailing streams, opening the interactive TUI,
  inspecting settings/build info, and bridging Linux systemd journal records
  into a DevLogBus broker.
- Public Go packages for broker clients, protocol types, and a non-blocking
  `slog.Handler` publisher.
- Browser publishing over HTTP, including the Chrome Browser Tap extension for
  console calls, runtime exceptions, browser log entries, and network request,
  response, and failure records.
- Dynamic source grouping via `sourceGroup`, including Chrome tab parent
  sources, child network target sources, page-title labels, merged/by-source
  group controls, and source/group popout windows with reattach.
- Terminal UI support for merged and by-source layouts, source-group drilldown,
  search, level filters, pause/follow-bottom, details, clear, expunge, and
  in-app help with `?` or `h`.
- Browser tap detach lifecycle records publish as `WARN` messages so the log
  stream clearly shows when Chrome-side capture has stopped.
